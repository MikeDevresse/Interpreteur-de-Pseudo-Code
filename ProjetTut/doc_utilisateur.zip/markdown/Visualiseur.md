## Visualisuer GUI
![Visualiseur GUI](https://i.imgur.com/FGn6dA4.png)
## Visualisuer CUI
![Visualiseur CUI](https://i.imgur.com/mrkk39S.png)