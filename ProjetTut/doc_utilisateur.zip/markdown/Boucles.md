## Structure
```
tq <conditon> alors
    instructions
ftq
```
* Voir [condition](Conditions)
