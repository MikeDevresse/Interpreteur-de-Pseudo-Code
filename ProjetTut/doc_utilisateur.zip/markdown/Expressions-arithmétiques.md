## Nous avons géré la successions de littéraux, variables ou constantes séparés par :

### Des opérateurs binaires : 
        + 
        -  
        × (pas un x miniscule mais un × (code ascii 215) Alt+0215) ; 
        / (division réelle 5 / 2 donnera 2.5)
        div (division entière 5 / 2 donnera 2)
        mod (récupérer reste d'une division, exemple 2 mod 2 donnera 0)
        ^   (pour faire la puissance, exemple : 2^2 donnera 4)
        \/¯ (pour la racine carrée)
### Des opérateur unaires : 
        + (exemple cpt++ incrémentera de 1 cpt)
        - (exemple cpt-- décrémentera de 1 cpt)
