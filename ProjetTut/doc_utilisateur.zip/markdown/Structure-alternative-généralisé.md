## Structure
```
selon <nom_var>
    cas <valeur> :
        <instructions>
    cas <valeur> :
        <instructions>
fselon
```