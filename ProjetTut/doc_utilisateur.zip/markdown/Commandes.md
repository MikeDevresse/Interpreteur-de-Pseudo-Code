* défaut : Passe à la ligne suivante
* "B" : Retourne à la ligne précédente
* "L<ligne>" : Avance a la ligne entrer après le L majuscule
* "+bk" : Ajoute un point d'arrêt à la ligne courante
* "-bk" : Supprime le point d'arrêt de la ligne courante
* "go bk" : Avance jusqu'au prochain point d'arrêt
* "cp tab <nom_var>" : Copie le contenu du tableau entré en paramètre jusqu'à deux dimensions dans le presse-papier
* "+ var <nom_var>" : Ajoute la variable entrer en paramètre dans les variables a inspecter
* "- var <nom_var>" : Supprime la variable entrer en paramètre dans des variables a inspecter
* "cp trace <nom_var>" : Copie la trace des variables de la variable entré en paramètre dans le presse papier