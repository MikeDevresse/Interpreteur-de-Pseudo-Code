## Comment l'utiliser ?
Exécuter la commande suivante : 
```
java -jar interpreteur.jar <fichier_.algo_en_pseudo-code> <fichier_de_configuration>
```
* Voir [fichier de configuration](Fichier-de-configuration)