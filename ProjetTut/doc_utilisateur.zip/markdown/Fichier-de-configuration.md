## Exemple
```
Syntaxe 
Obligatoire | Marche auto (oui/non) : ???	| Défini si la marche auto est active ou non
	    | Temp globale : durée en seconde	| Défini le temps entre 2 lignes par défaut
Facultatif  | Temp l(ligne) : durée en seconde	| Défini le temps entre 2 ligne à une ligne précise
	    | Comm l(ligne) : commentaire	| Ajoute un commentaire à la ligne renseigner
			

Marche auto (oui/non) : non
Temp globale : 1
Temp l10 : 10
Temp l8 : 5
Comm l10 : On entre dans la boucle jusqu'a ce que i soit supérieur ou égale à 6
```