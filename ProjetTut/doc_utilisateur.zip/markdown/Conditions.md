## Nous avons géré les conditions : 
### Structure
```
si <condition> alors
    instructions
fsi
```

## De plus, nous avons géré les expressions booléennes pour que les conditions puissent fonctionner : 

- les expressions booléennes simples à l'aide des opérateurs : < ; > ; <= ; >= ; = ; /= 
- les expressions booléennes composées  qui sont l'association d'expressions booléennes simples à l'aide des opérateurs : et ; ou ; xou ; non
 
