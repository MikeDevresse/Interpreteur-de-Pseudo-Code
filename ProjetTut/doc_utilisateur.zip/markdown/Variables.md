Une variable peut avoir 5 type :
* Entier
* Reel
* Booleen
* caractere
* chaine de caracteres

